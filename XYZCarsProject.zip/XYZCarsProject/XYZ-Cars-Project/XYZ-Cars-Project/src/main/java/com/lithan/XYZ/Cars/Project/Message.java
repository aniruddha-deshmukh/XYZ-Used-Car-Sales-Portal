package com.lithan.XYZ.Cars.Project;

public class Message {
	private String text;
	public String getText() {
		return text;
	}
}