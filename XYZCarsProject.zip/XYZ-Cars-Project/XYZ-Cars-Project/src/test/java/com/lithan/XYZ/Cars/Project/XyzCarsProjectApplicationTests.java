package com.lithan.XYZ.Cars.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XyzCarsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
